function addClick(url){
	  setTimeout(function(){
		  $.get(url);
	  },5000);
  }