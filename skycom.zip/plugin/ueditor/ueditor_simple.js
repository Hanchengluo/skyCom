options={
		initialFrameWidth:"100%",
		 toolbars:[
            [   'bold', 'italic', 'underline', 'strikethrough','forecolor',
                  'paragraph',   'fontsize',
                'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|',
                'link', 'unlink',
                'insertimage', 'emotion', 'attachment', 
                'horizontal', 
                'inserttable', 'deletetable', 
               ]
        ]
		 
};