<div class="tabs-border">
	<a class="item <?php if (get ( 'a' ) == 'default'): ?>active<?php endif; ?>" href="<?php echo $this->_var['appadmin']; ?>?m=link">链接管理</a>
    <a  class="item  <?php if (get ( 'a' ) == 'add'): ?>active<?php endif; ?>" href="<?php echo $this->_var['appadmin']; ?>?m=link&a=add">链接添加</a>
</div>