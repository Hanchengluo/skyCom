<div class="tabs-border">
	<a href="<?php echo $this->_var['appadmin']; ?>?m=article" class="item <?php if (get ( 'a' ) == 'default'): ?>active<?php endif; ?>">管理</a>
 <a href="<?php echo $this->_var['appadmin']; ?>?m=article&a=add" class="item  <?php if (get ( 'a' ) == 'add'): ?>active<?php endif; ?>">添加</a>
 </div>