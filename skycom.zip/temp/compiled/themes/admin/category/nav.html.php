<div class="tabs-border">
<a  class="<?php if (get ( 'a' ) == 'default'): ?>active<?php endif; ?> item"  href="<?php echo $this->_var['appadmin']; ?>?m=category">分类管理</a> 
<a  class="<?php if (get ( 'a' ) == 'add'): ?>active<?php endif; ?> item"  href="<?php echo $this->_var['appadmin']; ?>?m=category&a=add">分类添加</a> 
 
</div>