<div class="tabs-border">
<a href="<?php echo $this->_var['appadmin']; ?>?m=admin" class="<?php if (get ( 'a' ) == 'default'): ?>active<?php endif; ?> item">管理员</a>
<a href="<?php echo $this->_var['appadmin']; ?>?m=admin&a=add" class="<?php if (get ( 'a' ) == 'add'): ?>active<?php endif; ?> item">管理员添加</a>
</div>