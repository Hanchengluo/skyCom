<!DOCTYPE >
<html>
<?php echo $this->fetch('head.html'); ?>

<body>
<div class="tabs-border">
	<a href="javascript:;" class="item active">管理首页</a>
</div>
<div class="main-body w98">
<table width="100%" class="table table-bordered">
  <tr>
    <td width="15%">感谢您使用skyCom得推企业网站系统，当前版本：<?php echo VERSION; ?>。</td>
    </tr>
    
     
  
  <tr>
  	<td>技术支持： <div>QQ群：219949413  <a href="http://www.deitui.com/index.php?m=list&catid=37" target="_blank">技术论坛</a></div></td>
  </tr>
    
   
  
  
  
 
</table>
 <iframe src="<?php echo ONLINEUPDATE_NEWS; ?>" style="width:100%; min-height:200px; border:0px;"></iframe>
</div>

 

 <script language="javascript">
$(document).ready(function(){
	
	$.get("<?php echo $this->_var['appadmin']; ?>?m=index&a=CheckNewVersion",function(data){
		$("#newversion").html(data);
	});
	
	 
	
	$(document).on("click","#update_submit",function(){
		$("#update_loading").show();
		if(confirm('更新前请做好数据备份，确定更新吗？')){
			$.get("<?php echo $this->_var['appadmin']; ?>?m=index&a=update",function(data){
				skyToast(data.message);
				setTimeout(function(){
					window.location.reload();
				},2000);
			},"json")
		}else{
			$("#update_loading").hide();
		}
	});
});
</script>
<?php echo $this->fetch('footer.html'); ?>

</body>
</html>