<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<title>skymvc</title>
 
<link href="/plugin/iconfont/iconfont.css" rel="stylesheet">
<link href="http://skyweb.skymvc.com/skyweb/skyweb.css?v=<?php echo time(); ?>" rel="stylesheet">

<link href="/static/admin/admin.css?v=<?php echo time(); ?>" rel="stylesheet">
<script src="http://skyweb.skymvc.com/skyweb/jquery.js"></script>
<script src="http://skyweb.skymvc.com/skyweb/skyweb.js"></script>
<script src="/static/admin/admin.js"></script>
</head>

