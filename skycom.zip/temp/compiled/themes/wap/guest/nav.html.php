<div class="tabs-border">
	<a class="item" href="<?php echo R("/index.php?m=guest");?>">留言板</a>
	<a class="item" href="<?php echo R("/index.php?m=guest&a=add");?>">发布留言</a>
    <a class="item" href="<?php echo R("/index.php?m=guest&a=my");?>">我的留言</a>


</div>