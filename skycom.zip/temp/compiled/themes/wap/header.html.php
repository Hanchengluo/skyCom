<div class="header">
	<?php if ($this->_var['welcome']): ?><?php echo $this->_var['welcome']; ?><?php else: ?>这是头部<?php endif; ?>
</div>