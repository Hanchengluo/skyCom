<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<title>skymvc</title>
 
<link href="/plugin/iconfont/iconfont.css" rel="stylesheet">
<link href="/plugin/skyweb/skyweb.css" rel="stylesheet">
<link href="/plugin/skyweb/skywap.css" rel="stylesheet">
<link href="/static/css/wapapp.css" rel="stylesheet">
<script src="/plugin/skyweb/jquery.js"></script>
<script src="/plugin/skyweb/skyweb.js"></script>
<script src="/static/js/common.js"></script>
</head>

