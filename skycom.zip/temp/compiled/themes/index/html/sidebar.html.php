 <div class="cat-list"> 
           <div class="hd" style=""><span>公司信息</span></div>
           <div class="item"><a href="<?php echo R("/index.php?m=html&a=aboutus");?>">关于我们</a></div>
           <div class="item"><a href="<?php echo R("/index.php?m=html&a=contact");?>">联系我们</a></div> 
</div>  
  