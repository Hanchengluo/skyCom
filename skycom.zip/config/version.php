<?php
define("VERSION","skyCom V2.0");
define("VERSION_NUM",2.0); 
define("ONLINEUPDATE","http://www.deitui.com/index.php?m=newversion&a=update&product=skyCom");
define("CHECKVERSION","http://www.deitui.com/index.php?m=newversion&product=skyCom");
define("ONLINEUPDATE_DIR","http://www.deitui.com/onlineupdate/skyCom/");
define("ONLINEUPDATE_NEWS","http://www.deitui.com/index.php?m=list&catid=75");
?>
