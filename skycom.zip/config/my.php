<?php
$config['a']="aa";
?>