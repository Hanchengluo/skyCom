<?php
$config['thumb']=array(
	array("name"=>".100x100.jpg","w"=>100,"h"=>100,"all"=>1),
	array("name"=>".small.jpg","w"=>220,"h"=>999,"all"=>0),
	array("name"=>".middle.jpg","w"=>400,"h"=>999,"all"=>0),
);
?>