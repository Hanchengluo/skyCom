<?php
$sites["default"]="";
$sites[""]=1;
?>